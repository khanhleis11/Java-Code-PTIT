package j05076;

import java.util.*;

public class MatHang {
    private String id, name, loai;

    public MatHang(String id, String name, String loai) {
        this.id = id;
        this.name = name;
        this.loai = loai;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLoai() {
        return loai;
    }
    
}
