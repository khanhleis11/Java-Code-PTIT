package j05069;

public class CLB {
    private String idCLB, tenCLB;
    private int giaVe;

    public CLB(String idCLB, String tenCLB, int giaVe) {
        this.idCLB = idCLB;
        this.tenCLB = tenCLB;
        this.giaVe = giaVe;
    }

    public String getIdCLB() {
        return idCLB;
    }

    public String getTenCLB() {
        return tenCLB;
    }

    public int getGiaVe() {
        return giaVe;
    }
    
}
