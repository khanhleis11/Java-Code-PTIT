package j05067;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        ArrayList<DonHang> arr = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String s = sc.nextLine();
            String[] tmp = s.split("\\s+");
            DonHang x = new DonHang(tmp[0], Integer.parseInt(tmp[1]));
            arr.add(x);
        }
        for (DonHang x : arr) {
            System.out.println(x);
        }
    }
}
