package j07049;

import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class KhachHang implements Comparable<KhachHang>{
    private String idKH, tenKH, add;
    private int soLuong;
    private String ngayMua;
    private SanPham sp;

    public KhachHang(int idKH, String tenKH, String add, int soLuong, String ngayMua) {
        this.idKH = "KH" + String.format("%02d", idKH);
        this.tenKH = tenKH;
        this.add = add;
        this.soLuong = soLuong;
        this.ngayMua = ngayMua;
    }

    public void setSp(SanPham sp) {
        this.sp = sp;
    }
    
    public long getTongTien() {
        return (long)sp.getGiaBan() * this.soLuong;
    }
    
//    public String getNgayBaoHanh() {
//        Calendar cld = Calendar.getInstance();
//        String s = this.ngayMua;
//        String[] tmp = s.split("/");
//        String res = "";
//        cld.set(Integer.parseInt(tmp[2]), Integer.parseInt(tmp[1]), Integer.parseInt(tmp[0]));
//        cld.add(Calendar.MONTH, sp.getTgBaoHanh());
//        int d = cld.get(Calendar.DAY_OF_MONTH), m = cld.get(Calendar.MONTH), y = cld.get(Calendar.YEAR);
//        res += (String.format("%02d", d) + "/" + String.format("%02d", m) + "/" + y);
////        LocalDate ld = LocalDate.of(y, m, d);
//        return res;
//    }
    
    public String getNgayBaoHanh() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate purchaseDate = LocalDate.parse(this.ngayMua, formatter);
        LocalDate expirationDate = purchaseDate.plusMonths(sp.getTgBaoHanh());
        return expirationDate.format(formatter);
    }

    
    public LocalDate getDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return LocalDate.parse(this.getNgayBaoHanh(), formatter);
    }

    public String toString() {
        return this.idKH + " " + this.tenKH + " " + this.add + " " + sp.getIdSP() + " " + this.getTongTien() + " " + this.getNgayBaoHanh();
    }
    
    @Override
    public int compareTo(KhachHang o) {
        if (this.getDate().equals(o.getDate())) {
            return this.idKH.compareTo(o.idKH);
        }
        return this.getDate().compareTo(o.getDate());
    }
}
