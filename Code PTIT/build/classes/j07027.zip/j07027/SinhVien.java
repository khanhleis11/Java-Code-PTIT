package j07027;

public class SinhVien {
    private String idSV, tenSV, sdt;

    public SinhVien(String idSV, String tenSV, String sdt) {
        this.idSV = idSV;
        this.tenSV = tenSV;
        this.sdt = sdt;
    }

    public String getIdSV() {
        return idSV;
    }

    public String getTenSV() {
        return tenSV;
    }

    public String getSdt() {
        return sdt;
    }
}
