package j07027;

public class BaiTap {
    private String idBT, tenBT;

    public BaiTap(String tenBT) {
        this.tenBT = tenBT;
    }

    public String getTenBT() {
        return tenBT;
    }
    
}
