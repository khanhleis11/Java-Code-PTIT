package j07028;

public class GiangVien {
    private String idGV, tenGV;

    public GiangVien(String idGV, String tenGV) {
        this.idGV = idGV;
        this.tenGV = tenGV;
    }

    public String getIdGV() {
        return idGV;
    }

    public String getTenGV() {
        return tenGV;
    }
}
