package j07075;

public class MonHoc {
    private String idMonHoc, tenMonHoc;
    private int soTin;

    public MonHoc(String idMonHoc, String tenMonHoc, int soTin) {
        this.idMonHoc = idMonHoc;
        this.tenMonHoc = tenMonHoc;
        this.soTin = soTin;
    }

    public String getIdMonHoc() {
        return idMonHoc;
    }

    public String getTenMonHoc() {
        return tenMonHoc;
    }
}
