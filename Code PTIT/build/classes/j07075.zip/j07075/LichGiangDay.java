package j07075;

public class LichGiangDay implements Comparable<LichGiangDay> {
    private String idNhom, idMon, thu, kip, giangVien, phongHoc, tenMonHoc;
    
    public LichGiangDay(int idNhom, String idMon, String thu, String kip, String giangVien, String phongHoc) {
        this.idNhom = "HP" + String.format("%03d", idNhom);
        this.idMon = idMon;
        this.thu = thu;
        this.kip = kip;
        this.giangVien = giangVien;
        this.phongHoc = phongHoc;
//        this.tenMonHoc = tenMonHoc;
    }

    public void setTenMonHoc(String tenMonHoc) {
        this.tenMonHoc = tenMonHoc;
    }

    public String getIdMon() {
        return idMon;
    }
    
    public String getGiangVien() {
        return giangVien;
    }
    
    public String toString() {
        return this.idNhom + " " + tenMonHoc + " " + this.thu + " " + this.kip + " " + this.phongHoc;
    }
    
    public int compareTo(LichGiangDay o) {
        if (this.thu.equals(o.thu)) {
            if (this.kip.equals(o.kip)) {
                return this.giangVien.compareTo(o.giangVien);
            }
            return this.kip.compareTo(o.kip);
        }
        return this.thu.compareTo(o.thu);
    }
}
