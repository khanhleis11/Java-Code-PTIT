package j07075;

import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        int n = Integer.parseInt(sc.nextLine());
        HashMap<String, MonHoc> mp = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String idMonHoc = sc.nextLine();
            String tenMonHoc = sc.nextLine();
            int soTin = Integer.parseInt(sc.nextLine());
            mp.put(idMonHoc, new MonHoc(idMonHoc, tenMonHoc, soTin));
        }
        
        sc = new Scanner(new File("LICHGD.in"));
        n = Integer.parseInt(sc.nextLine());
        ArrayList<LichGiangDay> arr = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            LichGiangDay x = new LichGiangDay(i + 1, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(x);
        }
        Collections.sort(arr);
        String s = sc.nextLine();
        
        System.out.println("LICH GIANG DAY GIANG VIEN " + s + ":");
        for (LichGiangDay x : arr) {
            if (x.getGiangVien().equals(s)) {
                x.setTenMonHoc(mp.get(x.getIdMon()).getTenMonHoc());
                System.out.println(x);
            }
        }
    }
}
