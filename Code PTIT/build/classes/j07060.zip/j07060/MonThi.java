package j07060;

public class MonThi {
    private String idMT, tenMT, hinhThucThi;

    public MonThi(String idMT, String tenMT, String hinhThucThi) {
        this.idMT = idMT;
        this.tenMT = tenMT;
        this.hinhThucThi = hinhThucThi;
    }

    public String getIdMT() {
        return idMT;
    }
    
    public String getTenMT() {
        return tenMT;
    }
}
