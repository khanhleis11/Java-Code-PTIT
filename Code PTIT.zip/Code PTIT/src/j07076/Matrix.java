package j07076;

public class Matrix {
    private int n, m;
    private int[][] a = new int[n][m];
    
    
}
