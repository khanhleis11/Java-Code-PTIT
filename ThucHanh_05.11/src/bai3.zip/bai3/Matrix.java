package bai3;

public class Matrix {
    private int n, m;
    private int[][] a = new int[n][m];
}