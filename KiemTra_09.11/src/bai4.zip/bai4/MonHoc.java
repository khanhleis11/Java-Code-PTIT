package bai4;

public class MonHoc {
    private String idMH, tenMH;

    public MonHoc(String idMH, String tenMH) {
        this.idMH = idMH;
        this.tenMH = tenMH;
    }

    public String getIdMH() {
        return idMH;
    }

    public String getTenMH() {
        return tenMH;
    }

}
